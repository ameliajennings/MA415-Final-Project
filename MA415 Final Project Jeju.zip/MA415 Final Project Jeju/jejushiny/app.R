library(shiny)
library(tidyverse)
library(lubridate)
library(leaflet)
library(knitr)
library(DT)

# data
population_data <- read_csv("Data/Population__Households_and_Housing_Units_20250506035446.csv")
jeju_population <- population_data |> filter(`By administrative divisions(eup, myeon, dong)` %in% c("Jeju-si", "Seogwipo-si"))

fine_dust_data <- read_csv("Data/FineDust_PM2.5__by_Month_and_City_20250506030823.csv")
jeju_dust <- fine_dust_data |> filter(`Classification(2)` %in% c("Jeju", "Seogwipo"))
jeju_dust_long <- jeju_dust |> 
  pivot_longer(cols = starts_with("2024"), names_to = "Month", values_to = "PM25") |>
  mutate(PM25 = as.numeric(gsub("[^0-9]", "", PM25)))
jeju_dust_long$Month <- recode(factor(jeju_dust_long$Month),
                               "2024.05" = "May", "2024.06" = "June",
                               "2024.07" = "July", "2024.08" = "August",
                               "2024.09" = "September", "2024.10" = "October")

# demographics data
demographics_data <- read_csv("Data/Korean_demographics_2000-2022.csv") |> mutate(Date = mdy(Date))
korea_total <- demographics_data |>
  filter(Region == "Jeju") |>
  mutate(Year = year(Date))
korea_yearly <- korea_total |> group_by(Year) |> summarize(Natural_Growth_Rate = mean(Natural_growth_rate, na.rm = TRUE))

# summary table
growth_change <- demographics_data |> 
  mutate(Year = year(Date)) |> 
  filter(Year %in% c(2000, 2022)) |> 
  group_by(Region, Year) |> 
  summarize(Natural_growth_rate = mean(Natural_growth_rate, na.rm = TRUE), .groups = "drop") |> 
  pivot_wider(names_from = Year, values_from = Natural_growth_rate, names_prefix = "Year_") |> 
  mutate(Change = Year_2022 - Year_2000) |> 
  arrange(Change)

# UI
ui <- navbarPage("Jeju Island Project",
                 tabPanel("Home",
                          tags$h4("Welcome to Jeju Island!"),
                          tags$p("Jeju Island is known for its stunning natural landscapes, shown below."),
                          img(src = "jeju-island-beach.jpg", width = "600px"),
                          img(src = "jeju-overview.jpeg", width = "600px"),
                          img(src = "jeju.jpg", width = "600px")
                 ),
                 tabPanel("Map",
                          tags$h4("Map of Jeju Island"),
                          tags$p("The map shows the location of Jeju Island in South Korea."),
                          leafletOutput("map")
                 ),
                 tabPanel("Population Statistics",
                          tags$h4("Population Comparison: Jeju-si vs Seogwipo-si (2023)"),
                          tags$p("Comparing the populations of Jeju's two major cities."),
                          plotOutput("population_plot")
                 ),
                 tabPanel("Environmental Data",
                          tags$h4("Air Quality: PM2.5 Levels"),
                          tags$p("Track PM2.5 air pollution levels in Jeju and Seogwipo across months."),
                          sliderInput("month_range", "Select Months:", min = 1, max = 6, value = c(1,6), step = 1),
                          plotOutput("pm_plot")
                 ),
                 tabPanel("Aging Population",
                          tags$h4("Jeju's Natural Growth Rate Over Time"),
                          tags$p("Observe the trend of declining natural growth rates nationally."),
                          fluidRow(
                            column(6, selectInput("year_start", "Start Year:", choices = 2000:2022, selected = 2000)),
                            column(6, selectInput("year_end", "End Year:", choices = 2000:2022, selected = 2022))
                          ),
                          plotOutput("growth_plot")
                 ),
                 tabPanel("Summary Table",
                          tags$h4("Regions with Largest Natural Growth Rate Decline (2000–2022)"),
                          DT::dataTableOutput("summaryTable")
                 )
)

# server
server <- function(input, output, session) {
  
  output$map <- renderLeaflet({
    leaflet() |> addTiles() |> 
      addMarkers(lng = 126.5312, lat = 33.4996, popup = "Jeju Island") |> 
      setView(lng = 126.5312, lat = 33.4996, zoom = 9)
  })
  
  output$population_plot <- renderPlot({
    jeju_population |> 
      ggplot(aes(x = `By administrative divisions(eup, myeon, dong)`, 
                 y = as.numeric(`2023...2`), fill = `By administrative divisions(eup, myeon, dong)`)) +
      geom_bar(stat = "identity", position = position_dodge(), width = 0.6) +
      scale_fill_manual(values = c("#FF6F61", "#6BAED6")) +
      labs(x = "City", y = "Total Population") +
      theme_minimal() +
      theme(legend.position = "none")
  })
  
  output$pm_plot <- renderPlot({
    jeju_dust_long |> 
      filter(as.numeric(Month) >= input$month_range[1],
             as.numeric(Month) <= input$month_range[2]) |> 
      ggplot(aes(x = Month, y = PM25, color = `Classification(2)`, group = `Classification(2)`)) +
      geom_line(size = 1.5) +
      geom_point(size = 3) +
      scale_color_manual(values = c("#FFA07A", "#20B2AA")) +
      labs(x = "Month", y = "PM2.5 (ug/m3)", color = "City") +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1))
  })
  
  output$growth_plot <- renderPlot({
    korea_yearly |> 
      filter(Year >= input$year_start, Year <= input$year_end) |> 
      ggplot(aes(x = Year, y = Natural_Growth_Rate)) +
      geom_line(color = "#0072B2", size = 1.5) +
      geom_point(color = "#0072B2", size = 3) +
      labs(x = "Year", y = "Natural Growth Rate (%)") +
      theme_minimal(base_size = 14)
  })
  
  output$summaryTable <- DT::renderDataTable({
    growth_change |>
      mutate(
        Year_2000 = round(Year_2000, 2),
        Year_2022 = round(Year_2022, 2),
        Change = round(Change, 2)
      )
  })
}


shinyApp(ui, server)
